# Hướng Dẫn Cấu Hình VPS & Deploy (Toàn Tập)

Tài liệu này chứa **tất cả** những gì bạn cần để chạy website trên VPS (Production).

## 1. Cấu hình Backend (.env)

Trên VPS, mở file `.env` trong thư mục `backend` và sửa các dòng sau:

```ini
# --- Môi trường ---
FLASK_ENV=production

# --- Thư mục Upload (BẮT BUỘC SỬA) ---
# Dùng đường dẫn tuyệt đối. Ví dụ:
UPLOAD_FOLDER=/var/www/mauvanban/uploads

# --- Domain & CORS (Quan trọng) ---
# Cho phép domain của bạn và dashboard admin gọi API
CORS_ORIGINS=https://mauvanban.zluat.vn,https://admin.mauvanban.zluat.vn

# --- Cấu hình SePay (Thanh toán) ---
SEPAY_API_KEY=xxx
SEPAY_ACCOUNT_ID=xxx
SEPAY_SECRET_KEY=xxx
SEPAY_BANK_ACCOUNT=xxx
SEPAY_BANK_NAME=xxx
SEPAY_ENABLED=True
```

## 2. Cấu hình Frontend (Build React App)

Khi build frontend để up lên VPS, bạn phải chỉ định URL của API backend.

**Cách 1: Tạo file `.env.production` trong thư mục `mauvanban-client`**
```ini
VITE_API_URL=https://mauvanban.zluat.vn
```

**Cách 2: Build trực tiếp với biến môi trường**
Chạy lệnh này trên máy local của bạn trước khi copy folder `dist` lên VPS:
```bash
# Windows (Powershell)
$env:VITE_API_URL="https://mauvanban.zluat.vn"; npm run build

# Linux/Mac
VITE_API_URL=https://mauvanban.zluat.vn npm run build
```
Sau đó copy thư mục `dist` lên VPS.

## 3. Cấu hình SePay (Dashboard)

Để thanh toán hoạt động, SePay cần biết "gọi lại" (webhook) vào đâu khi khách chuyển tiền xong.

1. Truy cập [my.sepay.vn](https://my.sepay.vn)
2. Vào mục **Cấu hình tích hợp** (Webhook).
3. Điền **Webhook URL**:
   ```
   https://mauvanban.zluat.vn/api/sepay/webhook
   ```
   *(Thay domain của bạn vào)*
4. Lưu lại.

## 4. Cấu hình Nginx (Đầy đủ)

File: `/etc/nginx/sites-available/mauvanban.zluat.vn`

```nginx
server {
    server_name mauvanban.zluat.vn;

    root /var/www/mauvanban/frontend; # Trỏ vào folder 'dist' của frontend
    index index.html;

    # 1. Phục vụ Frontend (React)
    location / {
        try_files $uri $uri/ /index.html;
    }

    # 2. Proxy cho Backend API
    location /api {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # 3. Phục vụ File/Ảnh Upload (QUAN TRỌNG)
    location /uploads/documents/ {
        # Phải KHỚP với UPLOAD_FOLDER trong backend/.env
        alias /var/www/mauvanban/uploads/;
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }
}
```

## 5. Các lỗi thường gặp

### ❌ Lỗi 400 Bad Request khi thêm văn bản
- Nguyên nhân: Giá tiền quá lớn (> 100 triệu).
- Khắc phục: Chạy lệnh update DB trên VPS:
  ```bash
  source venv/bin/activate
  python backend/scripts/update_price_precision.py
  ```

### ❌ Lỗi ảnh không hiện (404 Not Found)
- Nguyên nhân: Nginx config sai `alias` hoặc chưa cấp quyền thư mục.
- Khắc phục:
  - Xem lại mục 4 ở trên.
  - Chạy `sudo chown -R www-data:www-data /var/www/mauvanban/uploads`
  - Chạy `sudo systemctl restart nginx`

### ❌ Lỗi SePay không cập nhật thanh toán
- Kiểm tra 3 thứ:
  1. Webhook URL trên SePay dashboard đúng chưa?
  2. `SEPAY_SECRET_KEY` trong `.env` backend có trùng với trên SePay không?
  3. Server backend có đang chạy không?
